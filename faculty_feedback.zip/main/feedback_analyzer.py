import google.generativeai as genai

GOOGLE_API_KEY = "AIzaSyB5IAY1e0H-lCdM9Nu2zr97zBNxi0UIrak"
genai.configure(api_key=GOOGLE_API_KEY)

def generate_faculty_review(questions, opinions):
    model = genai.GenerativeModel('gemini-pro')

    # Create a template for the AI model to generate the review
    template = """
    Provide a vey breif review for the faculty based on the feedback received from students. The questions along with the corresponding ratings from 1 to 5 are given. Do not use bold letters or make a list. use plain text within a 200 word limit, just describing the faculty review breifly.
    """

    # Format the template to fit the input format expected by the generative model
    formatted_template = template.strip().replace('\n', ' ')

    # Generate the prompt with questions and opinions
    prompt = formatted_template + "\n".join([f"Question: {question.text} Rating: {opinion.value} " for question, opinion in zip(questions, opinions)])
    print(prompt)
    response = model.generate_content(prompt)

    return response.text
